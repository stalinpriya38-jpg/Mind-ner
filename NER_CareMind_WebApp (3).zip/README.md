# NER CareMind – Cognitive Assistance Web App

## What this prototype contains
- Language-first onboarding with 10 North-Eastern India language options
- Patient profile: age, condition, severity, doctor and emergency contact
- Familiar-person / family / house photo upload
- Home-route and daily-routine memory prompts
- Medicine, hydration, appointment and daily-activity reminder fields
- Memory Match, Attention, Pattern Recognition and Routine Recall games
- Familiar photo recognition prompt
- Caregiver dashboard with activity count, points, level and history
- Browser localStorage for offline-friendly persistence
- Responsive mobile/tablet UI
- Browser text-to-speech for simple voice assistance

## Important safety design
Do NOT store real passwords, banking PINs, OTPs or account credentials. The "Memory item / safe clue" field is intended only for non-sensitive memory practice.

This is a prototype for a student/project demonstration. It is not a medical diagnostic, treatment, emergency alert, or clinical decision-making system.

## Run
Open `index.html` in Chrome/Edge/Firefox. No server is required for the basic prototype.

## PPT demo
For a PPT, you can submit a screenshot or screen-recording of the prototype. If your institution requires a public URL, upload these three files to a static hosting service such as GitHub Pages, Netlify, or Vercel.
