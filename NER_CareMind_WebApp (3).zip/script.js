const $=id=>document.getElementById(id);
let state=JSON.parse(localStorage.getItem("careMindState")||'{"score":0,"activities":0,"history":[],"profile":null,"photos":[]}');
const objects=["🍎","🔑","🌸","☕","📖","🧴","🕰️","🏠"];
const patterns=[["🔵","🟢","🔵","🟢","?"],["⭐","❤️","⭐","❤️","?"],["▲","●","■","▲","●","?"]];

function save(){localStorage.setItem("careMindState",JSON.stringify(state))}
function go(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"});if(id==="dashboard")updateUI();if(id==="caregiver")renderDashboard()}
function speakText(t){if("speechSynthesis" in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(t))}}
$("voiceBtn").onclick=()=>speakText(document.querySelector(".screen.active").innerText.slice(0,700));

function readFiles(input){
  [...input.files].forEach(file=>{const r=new FileReader();r.onload=e=>{state.photos.push(e.target.result);save();renderPhotos()};r.readAsDataURL(file)})
}
$("selfPhoto").onchange=e=>readFiles(e.target);$("familyPhotos").onchange=e=>readFiles(e.target);$("housePhotos").onchange=e=>readFiles(e.target);
function renderPhotos(){let box=$("photoPreview");box.innerHTML="";state.photos.forEach(src=>{let img=document.createElement("img");img.src=src;box.appendChild(img)});let g=$("peopleGallery");if(g){g.innerHTML="";state.photos.forEach(src=>{let img=document.createElement("img");img.src=src;g.appendChild(img)})}}
function saveProfile(){
  state.profile={name:$("pName").value||"Patient",age:$("pAge").value,language:$("pLang").value,contact:$("pContact").value,condition:$("condition").value,severity:$("severity").value,doctor:$("doctor").value,route:$("homeRoute").value,morning:$("morning").value,afternoon:$("afternoon").value,evening:$("evening").value,medicine:$("medicine").value,medicineTime:$("medicineTime").value,waterTime:$("waterTime").value,appointment:$("appointment").value,dailyNote:$("dailyNote").value,memoryClue:$("memoryClue").value};
  save(); $("greeting").textContent=`Hello ${state.profile.name}. Let's do a gentle activity.`;
  renderPhotos();go("dashboard");
}
function updateUI(){$("score").textContent=state.score;$("progressText").textContent=`${state.activities} activities completed`;$("progressFill").style.width=Math.min(100,state.activities*10)+"%";}

function showGame(id){
 document.querySelectorAll(".game-panel").forEach(x=>x.classList.add("hidden"));$(id).classList.remove("hidden");
 document.querySelectorAll(".game-tab").forEach(x=>x.classList.remove("active"));event.target.classList.add("active");
 if(id==="routine")setupRoutine();if(id==="pattern")setupPattern();
}
function award(points,name){state.score+=points;state.activities++;state.history.push({name,points,time:new Date().toLocaleString()});save();updateUI();speakText(`Well done. You earned ${points} points.`)}

let memorySet=[];
function startMemory(){
 memorySet=[...objects].sort(()=>Math.random()-.5).slice(0,4);
 $("memoryObjects").innerHTML=memorySet.map(x=>`<span class="object">${x}</span>`).join("");
 $("memoryStart").disabled=true;
 setTimeout(()=>{$("memoryObjects").innerHTML="<p>Which objects did you see?</p>";$("memoryChoices").innerHTML=objects.map(x=>`<button class="choice" onclick="selectMemory(this,'${x}')">${x}</button>`).join("")},2500)
}
let chosen=[];
function selectMemory(btn,x){btn.classList.toggle("selected");if(chosen.includes(x))chosen=chosen.filter(y=>y!==x);else chosen.push(x);if(chosen.length===4){let ok=chosen.every(x=>memorySet.includes(x))&&memorySet.every(x=>chosen.includes(x));$("memoryChoices").innerHTML=ok?'<p class="success">✓ Excellent memory!</p>':'<p class="warning">Good try. Let’s practice again gently.</p>';if(ok)award(10,"Memory Match");chosen=[];$("memoryStart").disabled=false}}

function startAttention(){
 const board=$("attentionBoard");board.innerHTML="";
 const target=Math.random()>.5?"●":"■";$("targetShape").textContent=target==="●"?"circle":"square";
 for(let i=0;i<15;i++){let b=document.createElement("button");b.className="attention-cell";let val=Math.random()<.35?target:(target==="●"?"■":"●");b.textContent=val;b.onclick=()=>{if(val===target){b.style.outline="4px solid #176b87";award(2,"Attention");}else{b.textContent="↺";}};board.appendChild(b)}
}

function setupPattern(){
 let p=patterns[Math.floor(Math.random()*patterns.length)];$("patternSeq").innerHTML=p.slice(0,-1).map(x=>`<span class="pattern-item">${x}</span>`).join("");
 let correct=p[p.length-1];let opts=["🔵","🟢","⭐","❤️","▲","●","■"].sort(()=>Math.random()-.5).slice(0,3);if(!opts.includes(correct))opts[0]=correct;
 $("patternChoices").innerHTML=opts.map(x=>`<button class="choice" onclick="checkPattern('${x}','${correct}')">${x}</button>`).join("")
}
function checkPattern(x,c){if(x===c){award(8,"Pattern Recognition");$("patternChoices").innerHTML='<p class="success">✓ Correct pattern!</p>'}else speakText("Good try. Look at the repeating pattern again.")}

function setupRoutine(){
 let r=(state.profile?.morning||"Wake up → Brush teeth → Breakfast → Medicine").split("→").map(x=>x.trim()).filter(Boolean);
 if(r.length<3)r=["Wake up","Brush teeth","Breakfast","Medicine"];
 r=r.sort(()=>Math.random()-.5);$("routineChoices").innerHTML=r.map((x,i)=>`<div class="routine-item" data-value="${x}" onclick="this.classList.toggle('selected');this.dataset.selected=this.classList.contains('selected')">${i+1}. ${x}</div>`).join("");
}
function checkRoutine(){let vals=[...document.querySelectorAll(".routine-item")].filter(x=>x.classList.contains("selected")).map(x=>x.dataset.value);let expected=(state.profile?.morning||"Wake up → Brush teeth → Breakfast → Medicine").split("→").map(x=>x.trim()).filter(Boolean);if(vals.length===expected.length && vals.every((v,i)=>v===expected[i]))award(8,"Routine Recall");else speakText("Good effort. Try remembering what happens first, next and last.")}
function renderDashboard(){
 if(!state.profile){$("patientSummary").innerHTML="<p>No profile saved yet.</p>";return}
 let p=state.profile;$("statActivities").textContent=state.activities;$("statPoints").textContent=state.score;$("statLevel").textContent=Math.floor(state.score/30)+1;
 $("patientSummary").innerHTML=`<p><b>Name:</b> ${p.name}</p><p><b>Age:</b> ${p.age||"—"}</p><p><b>Condition:</b> ${p.condition}</p><p><b>Severity:</b> ${p.severity}</p><p><b>Doctor:</b> ${p.doctor||"—"}</p><p><b>Emergency:</b> ${p.contact||"—"}</p>`;
 $("reminderSummary").innerHTML=`<p>💊 Medicine: ${p.medicine||"Not set"} ${p.medicineTime||""}</p><p>💧 Water: ${p.waterTime||"Not set"}</p><p>📅 Appointment: ${p.appointment||"Not set"}</p><p>📝 Daily: ${p.dailyNote||"Not set"}</p>`;
 $("history").innerHTML=state.history.length?state.history.slice().reverse().map(h=>`<div class="card"><b>${h.name}</b> — +${h.points} points <span class="muted">${h.time}</span></div>`).join(""):"<p>No activities yet.</p>"
}
window.addEventListener("load",()=>{if(state.profile){$("pName").value=state.profile.name||"";$("pAge").value=state.profile.age||"";$("pLang").value=state.profile.language||"";$("pContact").value=state.profile.contact||"";$("condition").value=state.profile.condition||"Dementia – unspecified";$("severity").value=state.profile.severity||"Not assessed";$("doctor").value=state.profile.doctor||"";$("homeRoute").value=state.profile.route||"";$("morning").value=state.profile.morning||"";$("afternoon").value=state.profile.afternoon||"";$("evening").value=state.profile.evening||"";$("medicine").value=state.profile.medicine||"";$("medicineTime").value=state.profile.medicineTime||"";$("waterTime").value=state.profile.waterTime||"";$("appointment").value=state.profile.appointment||"";$("dailyNote").value=state.profile.dailyNote||"";$("memoryClue").value=state.profile.memoryClue||"";renderPhotos()}updateUI()});
